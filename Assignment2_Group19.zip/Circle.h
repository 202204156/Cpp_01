#ifndef CIRCLE_H
#define CIRCLE_H

class Circle :public Shape {
protected:
	virtual void draw();
};

#endif