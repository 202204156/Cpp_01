#include <iostream>
using namespace std;

#include "GraphicEditor.h"
int main() {
	GraphicEditor graphicEditor;
	graphicEditor.run();

	return 0;
}