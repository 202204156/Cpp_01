#include <iostream>
using namespace std;

#include "Shape.h"
#include "Rect.h"

void Rect::draw() {
	cout << "Rectangle" << endl;
}