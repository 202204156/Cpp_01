#include <iostream>

using namespace std;

#include "Shape.h"
#include "Line.h"

void Line::draw() {
	cout << "Line" << endl;
}